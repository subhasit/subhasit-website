# Subhasit Next.js Website

A modern Next.js website for subhasit.com and *The Invisible Score*.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy to Vercel

1. Upload this folder to a GitHub repository.
2. In Vercel, click **Add New > Project**.
3. Import the repository.
4. Leave Framework Preset as **Next.js**.
5. Click **Deploy**.
6. Add your domains in **Project Settings > Domains**:
   - subhasit.com
   - www.subhasit.com
7. Update GoDaddy DNS using the records Vercel provides.

## Important

There is intentionally no `vercel.json` file. Vercel will auto-detect Next.js.
