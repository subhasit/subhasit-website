const amazonIndia = 'https://www.amazon.in/dp/B0H79YZHH6';
const amazonUS = 'https://www.amazon.com/INVISIBLE-SCORE-Algorithms-Decisions-Opportunities-ebook/dp/B0H79YZHH6';

const concepts = ['AI', 'Algorithms', 'Digital Footprints', 'Bias', 'Deepfakes', 'Credit Scores', 'Social Media', 'Privacy', 'Human-in-the-loop', 'Explainable AI'];
const resources = ['AI Glossary for Students', 'Parent Discussion Guide', 'Digital Footprint Checklist', 'Teacher Classroom Questions'];

export default function Home() {
  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#top">Subhasit Ratnam</a>
        <div>
          <a href="#book">Book</a>
          <a href="#resources">Resources</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </div>
      </nav>

      <section id="top" className="hero section">
        <div className="heroText">
          <p className="eyebrow">AI made understandable</p>
          <h1>Understanding AI shouldn't require a PhD.</h1>
          <p className="lead">Stories and practical insights that help students, parents, and professionals understand how invisible algorithms shape everyday life.</p>
          <div className="actions">
            <a className="button primary" href={amazonIndia} target="_blank">Buy on Amazon India</a>
            <a className="button" href="#book">Explore the Book</a>
          </div>
        </div>
        <div className="bookCard" aria-label="The Invisible Score book card">
          <div className="bookMock">
            <span>The Invisible Score</span>
            <small>How AI, Data & Algorithms Shape Life</small>
          </div>
          <p>Every click leaves a signal. Every signal shapes tomorrow.</p>
        </div>
      </section>

      <section id="book" className="section split">
        <div>
          <p className="eyebrow">Featured book</p>
          <h2>The Invisible Score</h2>
          <p>What if the biggest decisions in your life were being influenced by systems you couldn't even see?</p>
          <p>Through Maya, Jay, and Leo, this story introduces readers to AI, credit scores, social media algorithms, digital footprints, bias, phishing, deepfakes, privacy, and the choices we still control.</p>
          <div className="actions">
            <a className="button primary" href={amazonIndia} target="_blank">Amazon India</a>
            <a className="button" href={amazonUS} target="_blank">Amazon US</a>
          </div>
        </div>
        <div className="qrBox">
          <img src="/book-qr.png" alt="QR code for The Invisible Score Amazon page" />
          <h3>Scan to buy the book</h3>
          <p>This QR code points to the Amazon India listing.</p>
        </div>
      </section>

      <section className="section">
        <p className="eyebrow">What readers learn</p>
        <h2>Big AI ideas, explained through story.</h2>
        <div className="grid">
          {concepts.map((item) => <div className="tile" key={item}>{item}</div>)}
        </div>
      </section>

      <section id="resources" className="section alt">
        <p className="eyebrow">Resources</p>
        <h2>Free learning materials coming soon.</h2>
        <div className="cards">
          {resources.map((item) => (
            <article className="card" key={item}>
              <h3>{item}</h3>
              <p>Designed for students, parents, teachers, and curious readers.</p>
            </article>
          ))}
        </div>
      </section>

      <section id="about" className="section split">
        <div>
          <p className="eyebrow">About the author</p>
          <h2>Subhasit Ratnam</h2>
          <p>Subhasit Ratnam has spent over two decades working with technology, AI, machine learning, cloud, and financial systems. He writes to make complex ideas understandable for students, parents, and professionals.</p>
          <p><em>The Invisible Score</em> is his debut book, created to help readers see the systems quietly shaping modern life — and understand the choices still in their hands.</p>
        </div>
        <div className="quote">
          “Not everything that gets attention is worth attention.”
        </div>
      </section>

      <section id="contact" className="section contact">
        <h2>Bring AI literacy to your school, family, or community.</h2>
        <p>For book discussions, classroom resources, speaking, or collaboration, reach out through your preferred contact channel.</p>
        <a className="button primary" href="mailto:hello@subhasit.com">Contact Subhasit</a>
      </section>
    </main>
  );
}
