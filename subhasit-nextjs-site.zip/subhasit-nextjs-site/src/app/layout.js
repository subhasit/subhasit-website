import './globals.css';

export const metadata = {
  title: 'Subhasit Ratnam | The Invisible Score',
  description: 'AI made understandable through stories, practical insights, and The Invisible Score — a book about how algorithms shape everyday life.',
  metadataBase: new URL('https://subhasit.com'),
  openGraph: {
    title: 'The Invisible Score by Subhasit Ratnam',
    description: 'A story-driven guide to how AI, data, and algorithms shape money, education, careers, and everyday life.',
    url: 'https://subhasit.com',
    siteName: 'Subhasit Ratnam',
    type: 'website'
  }
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
